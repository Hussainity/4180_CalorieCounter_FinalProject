import myfitnesspal as mfp

def handler(event, context):
    client = mfp.Client('hussainm@gatech.edu', 'MFP4180')
    day = client.get_date(2020, 4, 19)
    print(day.meals)
    print(event)
    print(context)
